import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useLocation } from 'react-router-dom';

const MovieDetailPage = () => {
  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
//   const { imdbID } = useParams();

  const location = useLocation();
  const imdbID = location.state.imdbID;
  console.log('imdbId', location);


  useEffect(() => {
    const fetchMovieDetails = async () => {
      setLoading(true);
      setError('');

      try {
        const response = await axios.get(`http://www.omdbapi.com/?apikey=796184f5&i=${imdbID}`);
        if (response.status === 200 && response.data.Response === 'True') {
          setMovie(response.data);
        } else {
          setError(response.data.Error || 'Movie not found');
          setMovie(null);
        }
      } catch (error) {
        setError('An error occurred. Please try again later.');
        setMovie(null);
        console.error(error);
      }

      setLoading(false);
    };

    fetchMovieDetails();
  }, [imdbID]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p className="text-danger">{error}</p>;
  if (!movie) return null;

  return (
    <div>
      <h2>{movie.Title}</h2>
      <p>Year: {movie.Year}</p>
      <p>Director: {movie.Director}</p>
      <p>Language: {movie.Language}</p>
      <p>Country: {movie.Country}</p>
      <p>IMDB Rating: {movie.imdbRating}</p>
      {/* Add more details as needed */}
    </div>
  );
};

export default MovieDetailPage;
